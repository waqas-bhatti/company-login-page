import { useContext, createContext } from "react";

const LoginTheme = createContext({
  themeMode: "light",
  darkTheme: () => {},
  lightTheme: () => {},
});

const UserContext = createContext(); // Renamed from ThemePage to UserContext

export const ThemePage = LoginTheme.Provider;

export default function useTheme() {
  return useContext(LoginTheme, UserContext);
}
