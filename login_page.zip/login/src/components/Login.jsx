import React, { useState, useContext } from "react";
import UserContext from "../contexts/loginTheme";

function Login({ setUser }) {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [type, setType] = useState("password");
  const [errors, setErrors] = useState({ username: "", password: "" });

  const handleShowHide = () => {
    setType(type === "password" ? "text" : "password");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let valid = true;
    const newErrors = { username: "", password: "" };

    if (username.trim() === "") {
      newErrors.username = "Email is required";
      valid = false;
    }

    if (password.trim() === "") {
      newErrors.password = "Password is required";
      valid = false;
    }

    setErrors(newErrors);

    if (valid) {
      setUser({ username, password });
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-800 dark:border-gray-700 flex flex-col md:flex-row">
      <div className="flex w-full md:w-1/3 h-auto flex-col space-y-5 p-2 mt-10 md:mt-0 mx-1 md:mx-12">
        <div className="mx-auto mt-20 mb-2 space-y-3">
          <div className="w-24 md:w-1/2 mx-auto">
            <img
              className="w-full"
              src="https://propellus.co/cdn/shop/files/Propellus_Logo.png?v=1704069272&width=600"
              alt="propellus"
            />
          </div>
          <h1 className="text-3xl font-bold text-gray-700 dark:text-white text-center md:text-left">
            Login
          </h1>
          <p className="text-gray-500 dark:text-white text-center md:text-left">
            Please provide your email and password to access your Propellus
            account.
          </p>
        </div>

        <div>
          <div className="relative mt-2 w-full">
            <input
              type="text"
              value={username}
              onChange={(e) => setUserName(e.target.value)}
              className={`border-1 peer block w-full appearance-none rounded-lg border px-2.5 pb-2.5 pt-4 text-sm focus:outline-none focus:ring-0 ${
                errors.username
                  ? "border-red-500 text-red-600 focus:border-red-600"
                  : "border-gray-300 text-gray-900 focus:border-blue-600"
              } dark:text-white dark:bg-slate-800 dark:border-gray-300 dark:focus:border-blue-600`}
              placeholder=" "
            />
            <label className="absolute top-2 left-1 z-10 origin-[0] -translate-y-4 scale-75 transform cursor-text select-none bg-white dark:text-white dark:bg-gray-800 px-2 text-sm text-gray-500 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 peer-focus:text-blue-600 dark:peer-focus:text-white">
              Email
            </label>
          </div>
          {errors.username && (
            <p className=" mt-2 text-xs text-red-600 dark:text-red-400">
              {errors.username}
            </p>
          )}
        </div>

        <div>
          <div className="relative mt-2 w-full">
            <input
              type={type}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`border-1 peer block w-full appearance-none rounded-lg border px-2.5 pb-2.5 pt-4 text-sm focus:outline-none focus:ring-0 ${
                errors.password
                  ? "border-red-500 text-red-600 focus:border-red-600"
                  : "border-gray-300 text-gray-900 focus:border-blue-600"
              } dark:text-white dark:bg-slate-800 dark:border-gray-300 dark:focus:border-blue-600`}
              placeholder=" "
            />
            <button
              type="button"
              onClick={handleShowHide}
              className="absolute top-0 end-0 p-3.5 rounded-e-md"
            >
              <svg
                className="flex-shrink-0 size-4 text-blue-800 dark:text-white"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path
                  className={type === "password" ? "" : "hidden"}
                  d="M9.88 9.88a3 3 0 1 0 4.24 4.24"
                ></path>
                <path
                  className={type === "password" ? "" : "hidden"}
                  d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"
                ></path>
                <path
                  className={type === "password" ? "" : "hidden"}
                  d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"
                ></path>
                <line
                  className={type === "password" ? "" : "hidden"}
                  x1="2"
                  x2="22"
                  y1="2"
                  y2="22"
                ></line>
                <path
                  className={type === "password" ? "hidden" : ""}
                  d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"
                ></path>
                <circle
                  className={type === "password" ? "hidden" : ""}
                  cx="12"
                  cy="12"
                  r="3"
                ></circle>
              </svg>
            </button>
            <label
              htmlFor="password"
              className="absolute top-2 left-1 z-10 origin-[0] -translate-y-4 scale-75 transform cursor-text select-none bg-white dark:text-white dark:bg-gray-800 px-2 text-sm text-gray-500 duration-300 peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-75 peer-focus:px-2 peer-focus:text-blue-600 dark:peer-focus:text-white"
            >
              Password
            </label>
          </div>
          {errors.password && (
            <p className="mt-2 text-xs text-red-600 dark:text-red-400">
              {errors.password}
            </p>
          )}
        </div>

        <div className="flex items-center mb-4">
          <input
            type="checkbox"
            id="remember"
            className="w-4 h-4 text-blue-600 focus:ring-blue-500 focus:ring-1"
          />
          <label
            htmlFor="remember"
            className="ml-2 text-sm text-gray-700 dark:text-white"
          >
            Remember me
          </label>
          <a
            href="#"
            className="ml-auto text-sm text-blue-700 text-semi-bold hover:underline"
          >
            Reset password?
          </a>
        </div>

        <button
          onClick={handleSubmit}
          className="rounded-lg bg-blue-600 py-3 font-bold text-white"
        >
          Login
        </button>
      </div>
      <div className="hidden md:block md:w-2/3 h-screen">
        <img
          className="w-full h-full object-cover"
          src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?q=80&w=1472&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%D%"
          alt="Login background"
        />
      </div>
    </div>
  );
}

export default Login;
