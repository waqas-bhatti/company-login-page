import React from "react";
import ThemeBtn from "./ThemeBtn";

export default function Card() {
  return (
    <div className="h-screen bg-white  dark:bg-gray-800 dark:border-gray-700"></div>
  );
}
