import React, { useContext } from "react";
import useTheme from "../contexts/loginTheme";

function Profile() {
  const { user } = useTheme();
  if (!user) return <div>Please Login</div>;
  return <div>Welcome {user.username} </div>;
}

export default Profile;
