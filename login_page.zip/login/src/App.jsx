import { useEffect, useState } from "react";
import "./App.css";
import { ThemePage } from "./contexts/loginTheme";
import ThemeBtn from "./components/ThemeBtn";
import Login from "./components/Login";
import Profile from "./components/Profile";

function App() {
  const [themeMode, setThemeMode] = useState("light");

  const lightTheme = () => {
    setThemeMode("light");
  };
  const darkTheme = () => {
    setThemeMode("dark");
  };

  useEffect(() => {
    document.querySelector("html").classList.remove("light", "dark");
    document.querySelector("html").classList.add(themeMode);
  }),
    [themeMode];
  return (
    <ThemePage value={{ themeMode, lightTheme, darkTheme }}>
      <div className="w-full">
        <div className="flex justify-end p-3">
          <ThemeBtn />
        </div>
        <div className="w-full">
          <Login />
        </div>
      </div>
    </ThemePage>
  );
}

export default App;
